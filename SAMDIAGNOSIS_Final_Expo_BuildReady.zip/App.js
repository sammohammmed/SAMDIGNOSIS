// App.js
import React from "react";
import { View, Text, StyleSheet, StatusBar } from "react-native";

export default function App() {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <Text style={styles.title}>🧬 SAM-DIAGNOSIS</Text>
      <Text style={styles.text}>مرحبًا 👋 التطبيق جاهز للعمل!</Text>
      <Text style={styles.note}>قريبًا سيتم ربطه بالذكاء الاصطناعي.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0a0f1a",
    alignItems: "center",
    justifyContent: "center"
  },
  title: {
    color: "#00e0ff",
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8
  },
  text: {
    color: "#fff",
    fontSize: 18
  },
  note: {
    color: "#bbb",
    marginTop: 10
  }
});
